const express = require('express');
const nodemailer = require('nodemailer');
const cors = require('cors');
const multer = require('multer');
const csv = require('csv-parser');
const fs = require('fs');
const path = require('path');

const app = express();
const upload = multer({ dest: 'uploads/' });

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Store transporter and config globally
let transporter = null;
let smtpConfig = {};

// Configure SMTP
app.post('/api/configure-smtp', async (req, res) => {
  try {
    const { host, port, username, password, fromName, fromEmail, replyTo, companyAddress } = req.body;

    // Store config for later use
    smtpConfig = {
      fromName,
      fromEmail,
      replyTo: replyTo || fromEmail,
      companyAddress: companyAddress || ''
    };

    transporter = nodemailer.createTransport({
      host: host,
      port: parseInt(port),
      secure: port === '465', // true for 465, false for 587
      auth: {
        user: username,
        pass: password
      },
      tls: {
        rejectUnauthorized: true, // Changed to true for better security
        minVersion: 'TLSv1.2'
      },
      // Add connection pooling for better performance
      pool: true,
      maxConnections: 5,
      maxMessages: 100
    });

    // Verify connection
    await transporter.verify();

    res.json({ 
      success: true, 
      message: 'SMTP configured successfully',
      from: { name: fromName, email: fromEmail }
    });
  } catch (error) {
    console.error('SMTP Configuration Error:', error);
    res.status(400).json({ 
      success: false, 
      message: 'SMTP configuration failed', 
      error: error.message 
    });
  }
});

// Helper function to convert HTML to plain text (basic version)
function htmlToText(html) {
  return html
    .replace(/<style[^>]*>.*?<\/style>/gi, '')
    .replace(/<script[^>]*>.*?<\/script>/gi, '')
    .replace(/<[^>]+>/g, '')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/\s+/g, ' ')
    .trim();
}

// Helper function to add email footer
function addEmailFooter(html, companyAddress) {
  const footer = `
    <hr style="border: none; border-top: 1px solid #ddd; margin: 30px 0;">
    <div style="font-size: 12px; color: #666; line-height: 1.6;">
      ${companyAddress ? `<p>${companyAddress.replace(/\n/g, '<br>')}</p>` : ''}
      <p>
        <a href="{{unsubscribeUrl}}" style="color: #666; text-decoration: underline;">Unsubscribe</a> | 
        <a href="{{preferencesUrl}}" style="color: #666; text-decoration: underline;">Email Preferences</a>
      </p>
    </div>
  `;
  
  // Insert footer before closing body tag, or append if no body tag
  if (html.includes('</body>')) {
    return html.replace('</body>', footer + '</body>');
  } else {
    return html + footer;
  }
}

// Send single email
app.post('/api/send-email', async (req, res) => {
  try {
    const { to, firstName, subject, htmlContent, fromName, fromEmail } = req.body;

    if (!transporter) {
      return res.status(400).json({ 
        success: false, 
        message: 'SMTP not configured' 
      });
    }

    // Use stored config or override with request values
    const senderName = fromName || smtpConfig.fromName;
    const senderEmail = fromEmail || smtpConfig.fromEmail;

    // Personalize content
    const personalizedSubject = subject.replace(/\{\{firstName\}\}/g, firstName);
    let personalizedHtml = htmlContent.replace(/\{\{firstName\}\}/g, firstName);
    
    // Add footer with company info
    personalizedHtml = addEmailFooter(personalizedHtml, smtpConfig.companyAddress);
    
    // Convert HTML to plain text
    const textContent = htmlToText(personalizedHtml);

    const mailOptions = {
      from: `"${senderName}" <${senderEmail}>`,
      to: to,
      replyTo: smtpConfig.replyTo,
      subject: personalizedSubject,
      text: textContent, // Plain text version
      html: personalizedHtml,
      headers: {
        'X-Mailer': 'CustomMailer/1.0',
        'X-Priority': '3',
        'List-Unsubscribe': '<mailto:unsubscribe@' + senderEmail.split('@')[1] + '>',
      }
    };

    const info = await transporter.sendMail(mailOptions);

    res.json({ 
      success: true, 
      messageId: info.messageId,
      recipient: to 
    });
  } catch (error) {
    console.error('Send Email Error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to send email', 
      error: error.message 
    });
  }
});

// Send bulk emails
app.post('/api/send-bulk', async (req, res) => {
  try {
    const { recipients, subject, htmlContent, fromName, fromEmail, delayMs = 2000 } = req.body;

    if (!transporter) {
      return res.status(400).json({ 
        success: false, 
        message: 'SMTP not configured' 
      });
    }

    // Use stored config or override
    const senderName = fromName || smtpConfig.fromName;
    const senderEmail = fromEmail || smtpConfig.fromEmail;

    const results = [];
    let consecutiveFailures = 0;

    for (const recipient of recipients) {
      try {
        // Personalize content for each recipient
        const personalizedSubject = subject.replace(/\{\{firstName\}\}/g, recipient.firstName);
        let personalizedHtml = htmlContent.replace(/\{\{firstName\}\}/g, recipient.firstName);
        
        // Add footer
        personalizedHtml = addEmailFooter(personalizedHtml, smtpConfig.companyAddress);
        
        // Convert to plain text
        const textContent = htmlToText(personalizedHtml);

        const mailOptions = {
          from: `"${senderName}" <${senderEmail}>`,
          to: recipient.email,
          replyTo: smtpConfig.replyTo,
          subject: personalizedSubject,
          text: textContent,
          html: personalizedHtml,
          headers: {
            'X-Mailer': 'CustomMailer/1.0',
            'X-Priority': '3',
            'List-Unsubscribe': '<mailto:unsubscribe@' + senderEmail.split('@')[1] + '>',
          }
        };

        const info = await transporter.sendMail(mailOptions);

        results.push({
          email: recipient.email,
          firstName: recipient.firstName,
          status: 'sent',
          messageId: info.messageId,
          time: new Date().toISOString()
        });

        consecutiveFailures = 0; // Reset on success

        // Delay between emails to avoid rate limiting
        if (delayMs > 0) {
          await new Promise(resolve => setTimeout(resolve, delayMs));
        }
      } catch (error) {
        consecutiveFailures++;
        
        results.push({
          email: recipient.email,
          firstName: recipient.firstName,
          status: 'failed',
          error: error.message,
          time: new Date().toISOString()
        });

        // If too many consecutive failures, stop to avoid getting blocked
        if (consecutiveFailures >= 5) {
          results.push({
            email: 'system',
            status: 'stopped',
            error: 'Too many consecutive failures. Stopping to prevent account suspension.',
            time: new Date().toISOString()
          });
          break;
        }
      }
    }

    res.json({ 
      success: true, 
      results: results,
      total: recipients.length,
      sent: results.filter(r => r.status === 'sent').length,
      failed: results.filter(r => r.status === 'failed').length
    });
  } catch (error) {
    console.error('Bulk Send Error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Bulk send failed', 
      error: error.message 
    });
  }
});

// Parse CSV file
app.post('/api/upload-csv', upload.single('file'), (req, res) => {
  const results = [];
  const filePath = req.file.path;

  fs.createReadStream(filePath)
    .pipe(csv())
    .on('data', (data) => {
      // Look for email and firstName columns (case insensitive)
      const email = data.email || data.Email || data.EMAIL || '';
      const firstName = data.firstName || data.FirstName || data.firstname || 
                       data.first_name || data['First Name'] || data.name || data.Name || 'there';
      
      if (email && email.includes('@')) { // Basic email validation
        results.push({ 
          email: email.trim().toLowerCase(), 
          firstName: firstName.trim() 
        });
      }
    })
    .on('end', () => {
      // Delete uploaded file
      fs.unlinkSync(filePath);
      
      // Remove duplicates
      const uniqueResults = Array.from(
        new Map(results.map(item => [item.email, item])).values()
      );
      
      res.json({ 
        success: true, 
        recipients: uniqueResults,
        count: uniqueResults.length,
        duplicatesRemoved: results.length - uniqueResults.length
      });
    })
    .on('error', (error) => {
      // Clean up file on error
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
      
      res.status(500).json({ 
        success: false, 
        message: 'CSV parsing failed', 
        error: error.message 
      });
    });
});

// Test endpoint
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    message: 'Email server is running',
    smtpConfigured: transporter !== null,
    config: transporter ? {
      fromName: smtpConfig.fromName,
      fromEmail: smtpConfig.fromEmail,
      replyTo: smtpConfig.replyTo
    } : null
  });
});

// Test SMTP configuration
app.post('/api/test-email', async (req, res) => {
  try {
    const { testEmail } = req.body;

    if (!transporter) {
      return res.status(400).json({ 
        success: false, 
        message: 'SMTP not configured' 
      });
    }

    const mailOptions = {
      from: `"${smtpConfig.fromName}" <${smtpConfig.fromEmail}>`,
      to: testEmail,
      subject: 'Test Email - SMTP Configuration',
      text: 'This is a test email to verify your SMTP configuration is working correctly.',
      html: `
        <h2>SMTP Test Email</h2>
        <p>✅ Your SMTP configuration is working correctly!</p>
        <p>If you received this email in your inbox (not spam), your setup is good.</p>
        <hr>
        <p style="font-size: 12px; color: #666;">
          Sent from: ${smtpConfig.fromName} &lt;${smtpConfig.fromEmail}&gt;
        </p>
      `
    };

    const info = await transporter.sendMail(mailOptions);

    res.json({ 
      success: true, 
      message: 'Test email sent successfully',
      messageId: info.messageId
    });
  } catch (error) {
    console.error('Test Email Error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Test email failed', 
      error: error.message 
    });
  }
});

const PORT = process.env.PORT || 3001;

app.listen(PORT, () => {
  console.log(`✅ Email server running on http://localhost:${PORT}`);
  console.log(`📧 SMTP Status: ${transporter ? 'Configured' : 'Not configured'}`);
});